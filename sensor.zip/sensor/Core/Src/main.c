/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "string.h"
#include "math.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef unsigned char byte;
#define POLYNOMIAL_9 0x161
#define POLY 0x97

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */
uint16_t size_re=1;
uint8_t received;

//uint32_t crc_arr[50];
uint8_t ktir[5];
uint8_t old_ktir[5];

uint8_t kom[50];

uint16_t len;
uint16_t crc_len = 0;
uint8_t ramka[50];
uint8_t crc_val;

int posx=125;
int posy=125;

double i=0;
double j=0;
double k=0;
double g=0;
double h=0;
int flaga;

int lower = -150, upper = 150, count = 1;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */
unsigned char Fast_CRC_Cal8Bits(unsigned char crc, int Size, unsigned char *Buffer)
{
  static const unsigned char CrcTable[] = { // 0x97 Polynomial Table, 8-bit, sourcer32@gmail.com
    0x00,0x97,0xB9,0x2E,0xE5,0x72,0x5C,0xCB,
    0x5D,0xCA,0xE4,0x73,0xB8,0x2F,0x01,0x96,
    0xBA,0x2D,0x03,0x94,0x5F,0xC8,0xE6,0x71,
    0xE7,0x70,0x5E,0xC9,0x02,0x95,0xBB,0x2C,
    0xE3,0x74,0x5A,0xCD,0x06,0x91,0xBF,0x28,
    0xBE,0x29,0x07,0x90,0x5B,0xCC,0xE2,0x75,
    0x59,0xCE,0xE0,0x77,0xBC,0x2B,0x05,0x92,
    0x04,0x93,0xBD,0x2A,0xE1,0x76,0x58,0xCF,
    0x51,0xC6,0xE8,0x7F,0xB4,0x23,0x0D,0x9A,
    0x0C,0x9B,0xB5,0x22,0xE9,0x7E,0x50,0xC7,
    0xEB,0x7C,0x52,0xC5,0x0E,0x99,0xB7,0x20,
    0xB6,0x21,0x0F,0x98,0x53,0xC4,0xEA,0x7D,
    0xB2,0x25,0x0B,0x9C,0x57,0xC0,0xEE,0x79,
    0xEF,0x78,0x56,0xC1,0x0A,0x9D,0xB3,0x24,
    0x08,0x9F,0xB1,0x26,0xED,0x7A,0x54,0xC3,
    0x55,0xC2,0xEC,0x7B,0xB0,0x27,0x09,0x9E,
    0xA2,0x35,0x1B,0x8C,0x47,0xD0,0xFE,0x69,
    0xFF,0x68,0x46,0xD1,0x1A,0x8D,0xA3,0x34,
    0x18,0x8F,0xA1,0x36,0xFD,0x6A,0x44,0xD3,
    0x45,0xD2,0xFC,0x6B,0xA0,0x37,0x19,0x8E,
    0x41,0xD6,0xF8,0x6F,0xA4,0x33,0x1D,0x8A,
    0x1C,0x8B,0xA5,0x32,0xF9,0x6E,0x40,0xD7,
    0xFB,0x6C,0x42,0xD5,0x1E,0x89,0xA7,0x30,
    0xA6,0x31,0x1F,0x88,0x43,0xD4,0xFA,0x6D,
    0xF3,0x64,0x4A,0xDD,0x16,0x81,0xAF,0x38,
    0xAE,0x39,0x17,0x80,0x4B,0xDC,0xF2,0x65,
    0x49,0xDE,0xF0,0x67,0xAC,0x3B,0x15,0x82,
    0x14,0x83,0xAD,0x3A,0xF1,0x66,0x48,0xDF,
    0x10,0x87,0xA9,0x3E,0xF5,0x62,0x4C,0xDB,
    0x4D,0xDA,0xF4,0x63,0xA8,0x3F,0x11,0x86,
    0xAA,0x3D,0x13,0x84,0x4F,0xD8,0xF6,0x61,
    0xF7,0x60,0x4E,0xD9,0x12,0x85,0xAB,0x3C };

  while(Size--)
  {
    crc = crc ^ *Buffer++; // Apply Byte

    crc = CrcTable[crc & 0xFF]; // One round of 8-bits
  }

  return(crc);
}

unsigned char Slow_CRC_Cal8Bits(unsigned char crc, int Size, unsigned char *Buffer)
{
  int i;

  while(Size--)
  {
    crc = crc ^ *Buffer++; // Apply Byte

    for(i=0; i<8; i++) // Eight rounds of 1-bit
    {
      if (crc & 0x80)
        crc = (crc << 1) ^ POLY;
      else
        crc = (crc << 1); // Left Shifting
    }
  }

  return(crc);
}


//int _write(int file, uint8_t *ptr, int len){
//	HAL_UART_Transmit_IT(&huart1, ptr, len);
//	return  len;
//}

unsigned int CRC8_SingleByte(unsigned int Data2)
{
    unsigned int Poly = (POLYNOMIAL_9 << 7);
    for (byte Idx = 0; Idx < 8; ++Idx)
    {
        if ((Data2 & 0x8000) != 0)
            Data2 ^= Poly;
        Data2 <<= 1;
    }
    return Data2;
}

byte CRC8_DataArray(const byte *pDataFrame, byte Len)
{
    unsigned int Data2 = pDataFrame[0] << 8;

    for (unsigned int Idx = 1; Idx < Len; ++Idx)
    {
        Data2 |= pDataFrame[Idx];
        Data2 = CRC8_SingleByte(Data2);
    }
    Data2 = CRC8_SingleByte(Data2);

    return (byte)(Data2 >> 8);
}

void CreateDataFrame(uint8_t co, uint8_t ktory, uint8_t dane){
	crc_val = 0;

	crc_len = sprintf(ramka, "X %d %d %d", co, ktory, dane);
//	crc_val = Slow_CRC_Cal8Bits(crc_val, crc_len, ramka);
	crc_val = CRC8_DataArray(ramka, crc_len);
	len = sprintf(kom, "X %d %d %d %x\r\n", co, ktory, dane, crc_val);

	HAL_UART_Transmit_IT(&huart1, kom, len);
	HAL_Delay(300);

}

void readSensors(){
	ktir[0] = HAL_GPIO_ReadPin(KTIR1_GPIO_Port, KTIR1_Pin);
	ktir[1] = HAL_GPIO_ReadPin(KTIR2_GPIO_Port, KTIR2_Pin);
	ktir[2] = HAL_GPIO_ReadPin(KTIR3_GPIO_Port, KTIR3_Pin);
	ktir[3] = HAL_GPIO_ReadPin(KTIR4_GPIO_Port, KTIR4_Pin);
	ktir[4] = HAL_GPIO_ReadPin(KTIR5_GPIO_Port, KTIR5_Pin);
	if (ktir[0] != old_ktir[0]){
		CreateDataFrame(3, 1, ktir[0]);
	}
	if (ktir[1] != old_ktir[1]){
		CreateDataFrame(3, 2, ktir[1]);
	}
	if (ktir[2] != old_ktir[2]){
		CreateDataFrame(3, 3, ktir[2]);
	}
	if (ktir[3] != old_ktir[3]){
		CreateDataFrame(3, 4, ktir[3]);
	}
	if (ktir[4] != old_ktir[4]){
		CreateDataFrame(3, 5, ktir[4]);
	}
	old_ktir[0] = ktir[0];
	old_ktir[1] = ktir[1];
	old_ktir[2] = ktir[2];
	old_ktir[3] = ktir[3];
	old_ktir[4] = ktir[4];
}

void readSensors_all(){
	ktir[0] = HAL_GPIO_ReadPin(KTIR1_GPIO_Port, KTIR1_Pin);
	ktir[1] = HAL_GPIO_ReadPin(KTIR2_GPIO_Port, KTIR2_Pin);
	ktir[2] = HAL_GPIO_ReadPin(KTIR3_GPIO_Port, KTIR3_Pin);
	ktir[3] = HAL_GPIO_ReadPin(KTIR4_GPIO_Port, KTIR4_Pin);
	ktir[4] = HAL_GPIO_ReadPin(KTIR5_GPIO_Port, KTIR5_Pin);

	CreateDataFrame(3, 1, ktir[0]);


	CreateDataFrame(3, 2, ktir[1]);


	CreateDataFrame(3, 3, ktir[2]);
	HAL_Delay(50);
	CreateDataFrame(3, 4, ktir[3]);

	CreateDataFrame(3, 5, ktir[4]);
}

void Trasa(int i, int j){
	CreateDataFrame(2, (int)posx, (int)posy);
	if (i < 12){
	posy+=1;
	posx=125;
	}
	else if (j < 24){
	 posy-=1;
	 posx+=1;
	}
	else if (k < 36){
		posy-=1;
		posx-=1;
	}
	else if (g < 48) {
		posy+=1;
		posx-=1;
	}
	else if (h < 60){
		posy+=1;
		posx+=1;
	}
	else{
		posy+=0;
		posx-=1;
	}
	HAL_Delay(400);
}

void Speed (int lower, int upper, int count){
	int tmp;

	    for (tmp = 0; tmp < count; tmp++) {
	        int num = (rand() %
	           (upper - lower + 1)) + lower;
	        CreateDataFrame(1, 0, num);
	        num = (rand() %
	        	           (upper - lower + 1)) + lower;
	        CreateDataFrame(1, 1, num);
	    }
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
  len = sprintf(kom, "test\n\r");
  HAL_UART_Transmit_IT(&huart1, kom, len);
  HAL_Delay(500);
  ktir[0] = HAL_GPIO_ReadPin(KTIR1_GPIO_Port, KTIR1_Pin);
  ktir[1] = HAL_GPIO_ReadPin(KTIR2_GPIO_Port, KTIR2_Pin);
  ktir[2] = HAL_GPIO_ReadPin(KTIR3_GPIO_Port, KTIR3_Pin);
  ktir[3] = HAL_GPIO_ReadPin(KTIR4_GPIO_Port, KTIR4_Pin);
  ktir[4] = HAL_GPIO_ReadPin(KTIR5_GPIO_Port, KTIR5_Pin);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  readSensors();
	  Trasa(i,j);
	  //Speed(lower, upper, count);
//	  ktir[0] = HAL_GPIO_ReadPin(KTIR1_GPIO_Port, KTIR1_Pin);
//	  ktir[1] = HAL_GPIO_ReadPin(KTIR2_GPIO_Port, KTIR2_Pin);
//	  ktir[2] = HAL_GPIO_ReadPin(KTIR3_GPIO_Port, KTIR3_Pin);
//	  ktir[3] = HAL_GPIO_ReadPin(KTIR4_GPIO_Port, KTIR4_Pin);
//	  ktir[4] = HAL_GPIO_ReadPin(KTIR5_GPIO_Port, KTIR5_Pin);
//	  printf("%d %d %d %d %d\r\n", ktir[0], ktir[1], ktir[2], ktir[3], ktir[4]);



    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  i+=0.2;
	  j+=0.2;
	  k+=0.2;
	  g+=0.2;
	  h+=0.2;



  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 50;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV8;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV4;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, NCS_MEMS_SPI_Pin|CSX_Pin|OTG_FS_PSO_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(ACP_RST_GPIO_Port, ACP_RST_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, RDX_Pin|WRX_DCX_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOG, LD3_Pin|LD4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : KTIR1_Pin KTIR2_Pin KTIR3_Pin KTIR4_Pin
                           KTIR5_Pin */
  GPIO_InitStruct.Pin = KTIR1_Pin|KTIR2_Pin|KTIR3_Pin|KTIR4_Pin
                          |KTIR5_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : A0_Pin A1_Pin A2_Pin A3_Pin
                           A4_Pin A5_Pin SDNRAS_Pin A6_Pin
                           A7_Pin A8_Pin A9_Pin */
  GPIO_InitStruct.Pin = A0_Pin|A1_Pin|A2_Pin|A3_Pin
                          |A4_Pin|A5_Pin|SDNRAS_Pin|A6_Pin
                          |A7_Pin|A8_Pin|A9_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /*Configure GPIO pins : SPI5_SCK_Pin SPI5_MISO_Pin SPI5_MOSI_Pin */
  GPIO_InitStruct.Pin = SPI5_SCK_Pin|SPI5_MISO_Pin|SPI5_MOSI_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF5_SPI5;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /*Configure GPIO pin : ENABLE_Pin */
  GPIO_InitStruct.Pin = ENABLE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF14_LTDC;
  HAL_GPIO_Init(ENABLE_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : SDNWE_Pin */
  GPIO_InitStruct.Pin = SDNWE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
  HAL_GPIO_Init(SDNWE_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : NCS_MEMS_SPI_Pin CSX_Pin OTG_FS_PSO_Pin */
  GPIO_InitStruct.Pin = NCS_MEMS_SPI_Pin|CSX_Pin|OTG_FS_PSO_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : B1_Pin MEMS_INT1_Pin MEMS_INT2_Pin TP_INT1_Pin */
  GPIO_InitStruct.Pin = B1_Pin|MEMS_INT1_Pin|MEMS_INT2_Pin|TP_INT1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : B5_Pin VSYNC_Pin G2_Pin R4_Pin
                           R5_Pin */
  GPIO_InitStruct.Pin = B5_Pin|VSYNC_Pin|G2_Pin|R4_Pin
                          |R5_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF14_LTDC;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : ACP_RST_Pin */
  GPIO_InitStruct.Pin = ACP_RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(ACP_RST_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : OTG_FS_OC_Pin */
  GPIO_InitStruct.Pin = OTG_FS_OC_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(OTG_FS_OC_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : R3_Pin R6_Pin */
  GPIO_InitStruct.Pin = R3_Pin|R6_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF9_LTDC;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : BOOT1_Pin */
  GPIO_InitStruct.Pin = BOOT1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(BOOT1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : A10_Pin A11_Pin BA0_Pin BA1_Pin
                           SDCLK_Pin SDNCAS_Pin */
  GPIO_InitStruct.Pin = A10_Pin|A11_Pin|BA0_Pin|BA1_Pin
                          |SDCLK_Pin|SDNCAS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /*Configure GPIO pins : D4_Pin D5_Pin D6_Pin D7_Pin
                           D8_Pin D9_Pin D10_Pin D11_Pin
                           D12_Pin NBL0_Pin NBL1_Pin */
  GPIO_InitStruct.Pin = D4_Pin|D5_Pin|D6_Pin|D7_Pin
                          |D8_Pin|D9_Pin|D10_Pin|D11_Pin
                          |D12_Pin|NBL0_Pin|NBL1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : G4_Pin G5_Pin B6_Pin B7_Pin */
  GPIO_InitStruct.Pin = G4_Pin|G5_Pin|B6_Pin|B7_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF14_LTDC;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : OTG_HS_ID_Pin OTG_HS_DM_Pin OTG_HS_DP_Pin */
  GPIO_InitStruct.Pin = OTG_HS_ID_Pin|OTG_HS_DM_Pin|OTG_HS_DP_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF12_OTG_HS_FS;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : VBUS_HS_Pin */
  GPIO_InitStruct.Pin = VBUS_HS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(VBUS_HS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : D13_Pin D14_Pin D15_Pin D0_Pin
                           D1_Pin D2_Pin D3_Pin */
  GPIO_InitStruct.Pin = D13_Pin|D14_Pin|D15_Pin|D0_Pin
                          |D1_Pin|D2_Pin|D3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : TE_Pin */
  GPIO_InitStruct.Pin = TE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(TE_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : RDX_Pin WRX_DCX_Pin */
  GPIO_InitStruct.Pin = RDX_Pin|WRX_DCX_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : R7_Pin DOTCLK_Pin B3_Pin */
  GPIO_InitStruct.Pin = R7_Pin|DOTCLK_Pin|B3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF14_LTDC;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /*Configure GPIO pins : HSYNC_Pin G6_Pin R2_Pin */
  GPIO_InitStruct.Pin = HSYNC_Pin|G6_Pin|R2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF14_LTDC;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : I2C3_SDA_Pin */
  GPIO_InitStruct.Pin = I2C3_SDA_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF4_I2C3;
  HAL_GPIO_Init(I2C3_SDA_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : I2C3_SCL_Pin */
  GPIO_InitStruct.Pin = I2C3_SCL_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF4_I2C3;
  HAL_GPIO_Init(I2C3_SCL_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : G7_Pin B2_Pin */
  GPIO_InitStruct.Pin = G7_Pin|B2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF14_LTDC;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : G3_Pin B4_Pin */
  GPIO_InitStruct.Pin = G3_Pin|B4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF9_LTDC;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /*Configure GPIO pins : LD3_Pin LD4_Pin */
  GPIO_InitStruct.Pin = LD3_Pin|LD4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /*Configure GPIO pins : SDCKE1_Pin SDNE1_Pin */
  GPIO_InitStruct.Pin = SDCKE1_Pin|SDNE1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
